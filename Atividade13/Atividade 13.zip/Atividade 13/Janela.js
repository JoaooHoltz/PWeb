let quebrada = false;
 
function abrirJanela() {
 
    if (quebrada == false) {
 
        document.getElementById("janela").src = "Janela_Aberta.png";
 
        document.getElementById("titulo").innerText =
            "Janela Aberta";
    }
}
 
function fecharJanela() {
 
    if (quebrada == false) {
 
        document.getElementById("janela").src = "Janela_Fechada.png";
 
        document.getElementById("titulo").innerText =
            "Janela Fechada";
    }
}
 
function quebrarJanela() {
 
    document.getElementById("janela").src = "Janela_Quebrada.png";
 
    document.getElementById("titulo").innerText =
        "Janela Quebrada";
 
    quebrada = true;
}
 