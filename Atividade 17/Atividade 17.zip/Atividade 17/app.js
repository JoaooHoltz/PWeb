let app = require('./app/config/server');
let texto = require('./modulo1');

let rotaHome = require ('./app/routes/home');
rotaHome(app);

let rotaAdicionarUsuarios = require ('./app/routes/adicionar_usuarios');
rotaAdicionarUsuarios(app);

let rotaHistoria = require('./app/routes/historia');
rotaHistoria(app);

let rotaCursos = require('./app/routes/cursos');
rotaCursos(app);

let rotaProfessores = require('./app/routes/professores');
rotaProfessores(app);

/*app.get('/',function(req,res){
    res.render("home/index");
});*/

    /*app.get('/formulario_adicionar_usuario', function(req,res){
    res.render("admin/adicionar_usuario");
});*/

/*app.get('/', function (req,res){                                      Isso aqui foi
    res.send("<html><body>Site da Fatec Sorocaba</body></html>");       usado anteriormente
});*/

/*app.get('/informacao/historia',function(req,res){
    //res.send("<html><body>História da Fatec Sorocaba</body></html>"); Isso aqui foi usado anteriormente
    res.render("informacao/historia");
});*/

/*app.get('/informacao/cursos',function(req,res){
    //res.send("<html><body>Cursos da Fatec Sorocaba</body></html>");   Isso aqui foi usado anteriormente
    res.render("informacao/cursos");
});*/

/*app.get('/informacao/professores',function(req,res){
    //res.send("<html><body>Professores da Fatec Sorocaba</body></html>");  Isso aqui foi usado anteriormente
    res.render("informacao/professores");
});*/

app.listen(3000, function() {
    console.log("Olha só, o servidor foi iniciado");
});