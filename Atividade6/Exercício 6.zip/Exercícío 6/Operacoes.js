n1=prompt("Digite o primeiro número:");
n2=prompt("Digite o segundo número:");
numero1=parseFloat(n1);
numero2=parseFloat(n2);
soma=numero1+numero2;
subtracao=numero1-numero2;
multiplicacao=numero1*numero2;
divisao=numero1/numero2;
modulo=numero1%numero2;

alert("A soma dos números é: " + soma);
alert("A subtração dos números é: " + subtracao);
alert("A multiplicação dos números é: " + multiplicacao);
alert("A divisão dos números é: " + divisao.toFixed(2));
alert("O módulo dos números é: " + modulo);