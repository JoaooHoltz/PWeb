nome = prompt("Digite o nome do aluno:");
nota1 = parseFloat(prompt("Digite a primeira nota:"));
nota2 = parseFloat(prompt("Digite a segunda nota:"));
nota3 = parseFloat(prompt("Digite a terceira nota:"));
nota4 = parseFloat(prompt("Digite a quarta nota:"));
media = (nota1 + nota2 + nota3 + nota4) / 4;

alert("A média do aluno " + nome + " é: " + media.toFixed(2));