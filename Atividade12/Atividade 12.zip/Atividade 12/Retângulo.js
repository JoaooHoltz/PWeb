// Função construtora
function Retangulo(base, altura) {
    this.base = base;
    this.altura = altura;

    this.calcularArea = function () {
        return this.base * this.altura;
    };
}

// Função para pegar os dados do input
function calcularArea() {

    let base = Number(document.getElementById("base").value);
    let altura = Number(document.getElementById("altura").value);

    // Criando objeto
    let retangulo = new Retangulo(base, altura);

    // Executando método
    let area = retangulo.calcularArea();

    document.getElementById("resultado").innerHTML =
        "Área do retângulo: " + area;
}